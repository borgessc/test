influxdb
==============

Ansible role to install and configure InfluxDB.


## Example

```
- hosts: myhost

  vars:

  roles:
    - layer2pty.influxdb
```


## Testing

To run this role's integration tests

```
kitchen test
```


## Dependencies

none
